# app.py

from flask import Flask, render_template, request, redirect, url_for, session, g, jsonify
from werkzeug.security import generate_password_hash, check_password_hash
import sqlite3
import os
import json # Importamos json para la persistencia de los datos de votación

# --- Configuración de la Aplicación Flask ---
app = Flask(__name__)
# ¡IMPORTANTE! Cambia esto por una clave secreta real y compleja.
# Se usa para firmar las cookies de sesión y proteger contra la manipulación.
app.config['SECRET_KEY'] = 'Astl.2005'
app.config['DATABASE'] = 'instance/site.db' # Ruta de tu archivo de base de datos SQLite
app.config['VOTE_DATA_FILE'] = 'instance/vote_data.json' # Archivo para persistir los votos

# --- Variables globales para votos (se cargarán/guardarán desde/hacia JSON) ---
vote_data = {} # Se inicializa vacío y se carga al inicio

# --- Funciones para la Base de Datos SQLite ---
def get_db():
    db = getattr(g, '_database', None)
    if db is None:
        db = g._database = sqlite3.connect(app.config['DATABASE'])
        db.row_factory = sqlite3.Row # Esto permite acceder a las columnas por nombre
    return db

@app.teardown_appcontext
def close_connection(exception):
    db = getattr(g, '_database', None)
    if db is not None:
        db.close()

def init_db():
    # Crea la carpeta 'instance' si no existe
    os.makedirs('instance', exist_ok=True)
    with app.app_context():
        db = get_db()
        db.execute('''
            CREATE TABLE IF NOT EXISTS users (
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                username TEXT UNIQUE NOT NULL,
                password TEXT NOT NULL,
                role TEXT NOT NULL DEFAULT 'voter' -- Roles: 'voter', 'evaluator', 'approver'
            )
        ''')
        db.commit()
        # Opcional: Crear usuarios de ejemplo si no existen
        cursor = db.execute("SELECT id FROM users WHERE username = 'admin'")
        admin_exists = cursor.fetchone()
        if not admin_exists:
            hashed_password = generate_password_hash('adminpass') # ¡CAMBIA ESTA CONTRASEÑA EN UN ENTORNO REAL!
            db.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                       ('admin', hashed_password, 'evaluator')) # Rol 'evaluator' para el admin inicial
            db.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                       ('aprobador', generate_password_hash('aprobadorpass'), 'approver')) # Rol 'approver'
            db.execute("INSERT INTO users (username, password, role) VALUES (?, ?, ?)",
                       ('evaluado1', generate_password_hash('evaluadopass'), 'voter')) # Rol 'voter' de ejemplo
            db.commit()
            print("Base de datos inicializada y usuario 'admin', 'aprobador' y 'evaluado1' creados.")

def load_vote_data():
    global vote_data
    if os.path.exists(app.config['VOTE_DATA_FILE']):
        with open(app.config['VOTE_DATA_FILE'], 'r') as f:
            vote_data = json.load(f)
    else:
        # Inicializar vote_data si el archivo no existe
        vote_data = {
            "pagina1": {"total_votes": 0, "total_score": 0, "voters": []},
            "pagina2": {"total_votes": 0, "total_score": 0, "voters": []},
            "pagina3": {"total_votes": 0, "total_score": 0, "voters": []}
        }
        save_vote_data() # Guardar la estructura inicial

def save_vote_data():
    with open(app.config['VOTE_DATA_FILE'], 'w') as f:
        json.dump(vote_data, f, indent=4) # indent=4 para una lectura más fácil del JSON

# --- Rutas de la Aplicación ---

@app.before_request
def before_request():
    # Asegúrate de cargar los datos de votación antes de cada solicitud
    if not vote_data: # Solo cargar si está vacío (primera vez o reinicio)
        load_vote_data()

@app.route('/')
def index():
    # Si el usuario ya está logueado, redirigir al dashboard
    if 'user_id' in session:
        return redirect(url_for('dashboard'))
    return render_template('login.html')

@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        hashed_password = generate_password_hash(password)

        db = get_db()
        try:
            db.execute("INSERT INTO users (username, password) VALUES (?, ?)", (username, hashed_password))
            db.commit()
            return redirect(url_for('login')) # Redirige al login después de un registro exitoso
        except sqlite3.IntegrityError:
            # En caso de que el username ya exista
            return render_template('register.html', error="El nombre de usuario ya existe.")
    return render_template('register.html')

@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        db = get_db()
        cursor = db.execute("SELECT * FROM users WHERE username = ?", (username,))
        user = cursor.fetchone() # Obtiene la primera fila que coincida

        if user and check_password_hash(user['password'], password):
            session['user_id'] = user['id']
            session['username'] = user['username']
            session['role'] = user['role'] # Guarda el rol en la sesión
            return redirect(url_for('dashboard'))
        else:
            return render_template('login.html', error="Nombre de usuario o contraseña incorrectos.")
    return render_template('login.html')

@app.route('/logout')
def logout():
    session.pop('user_id', None)
    session.pop('username', None)
    session.pop('role', None)
    return redirect(url_for('login'))

@app.route('/dashboard')
def dashboard():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('dashboard.html', username=session['username'], role=session['role'])

# --- Rutas para las páginas en competencia ---
@app.route('/pagina1')
def pagina1():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('pages1.html', page_id="pagina1")

@app.route('/pagina2')
def pagina2():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('pages2.html', page_id="pagina2")

@app.route('/pagina3')
def pagina3():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('pages3.html', page_id="pagina3")

# --- Rutas para la votación ---
# app.py

# app.py

@app.route('/vote', methods=['GET', 'POST'])
def vote():
    if 'user_id' not in session:
        return redirect(url_for('login'))

    user_id = session['user_id']

    if request.method == 'POST':
        print("Datos del formulario recibidos:", request.form) # Mantener para depuración

        # Diccionario para almacenar los votos válidos para este envío
        votos_validos_recibidos = {} 

        # Bandera para saber si al menos un voto fue recibido y válido
        algun_voto_valido_enviado = False

        for i in range(1, 4): # Para pagina1, pagina2, pagina3
            page_id = f'pagina{i}'
            score_str = request.form.get(f'score_{page_id}')

            # Si se envió un valor (no es None y no es cadena vacía de la opción "Selecciona...")
            if score_str and score_str != '': 
                try:
                    score = int(score_str)
                    if 1 <= score <= 5:
                        # Guardar el voto válido temporalmente
                        votos_validos_recibidos[page_id] = score
                        algun_voto_valido_enviado = True
                    else:
                        # Error: la puntuación está fuera del rango (aunque el select lo limita, es buena práctica)
                        return render_template('vote.html', error="La puntuación debe ser entre 1 y 5 para todas las opciones válidas.", vote_data=vote_data)
                except ValueError:
                    # Error: el valor enviado no es un número
                    return render_template('vote.html', error="La puntuación debe ser un número entero para todas las opciones válidas.", vote_data=vote_data)
            # else: Si score_str es None o '', simplemente ignoramos este campo, lo que significa que no se votó por esa página.

        # Después de procesar todos los campos del formulario:
        if algun_voto_valido_enviado:
            # Ahora, aplicar los votos válidos a vote_data
            for page_id, score in votos_validos_recibidos.items():
                # Verificar si el usuario ya votó por esta página (para evitar votos duplicados)
                if user_id not in vote_data[page_id]["voters"]:
                    vote_data[page_id]["total_votes"] += 1
                    vote_data[page_id]["total_score"] += score
                    vote_data[page_id]["voters"].append(user_id)

            save_vote_data()
            return redirect(url_for('results'))
        else:
            # Si no se encontró ningún voto válido para ninguna página
            return render_template('vote.html', error="Debes seleccionar al menos una puntuación válida para enviar.", vote_data=vote_data)

    # GET request para mostrar el formulario de votación
    return render_template('vote.html', vote_data=vote_data)

@app.route('/get_vote_data')
def get_vote_data():
    # Endpoint para que el JavaScript del frontend obtenga los datos de votación
    if 'user_id' not in session:
        return jsonify({"error": "No autorizado"}), 401
    
    # Prepara los datos para el frontend, excluyendo 'voters' por privacidad
    display_data = {}
    for page, data in vote_data.items():
        # Calcular el promedio solo si hay votos
        average_score = data["total_score"] / data["total_votes"] if data["total_votes"] > 0 else 0
        display_data[page] = {
            "total_votes": data["total_votes"],
            "total_score": data["total_score"],
            "average_score": round(average_score, 2) # Redondear para mostrar
        }
    return jsonify(display_data)

@app.route('/results')
def results():
    if 'user_id' not in session:
        return redirect(url_for('login'))
    return render_template('results.html', vote_data=vote_data) # Pasar vote_data al template

@app.route('/awards')
def awards():
    # Solo los roles 'evaluator' y 'approver' pueden acceder a esta página
    if 'user_id' not in session or session.get('role') not in ['evaluator', 'approver']:
        return redirect(url_for('dashboard')) # Redirige a un lugar seguro si no tiene el rol

    winner = None
    max_average_score = -1.0
    
    # Filtrar solo páginas con al menos 3 votos para considerar un ganador
    eligible_pages = {p_id: data for p_id, data in vote_data.items() if data["total_votes"] >= 3}

    if eligible_pages:
        # Encontrar la página con el promedio más alto
        for page_id, data in eligible_pages.items():
            current_average = data["total_score"] / data["total_votes"]
            if current_average > max_average_score:
                max_average_score = current_average
                winner = page_id
            elif current_average == max_average_score:
                # Criterio de desempate: si los promedios son iguales, el que tenga más votos
                if data["total_votes"] > vote_data[winner]["total_votes"]:
                    winner = page_id
        
        # Si todavía hay un empate perfecto (mismo promedio y mismo número de votos),
        # puedes elegir uno arbitrariamente o por orden alfabético/numérico
        
    return render_template('awards.html', winner=winner, vote_data=vote_data)

# --- Inicialización y Ejecución de la Aplicación ---
if __name__ == '__main__':
    # Inicializa la DB y carga/crea los usuarios de ejemplo la primera vez.
    # Después de la primera ejecución exitosa, puedes comentar init_db()
    with app.app_context():
    # init_db()
    
    # Cargar los datos de votación al iniciar la aplicación
        load_vote_data() 
    
    app.run(debug=True)