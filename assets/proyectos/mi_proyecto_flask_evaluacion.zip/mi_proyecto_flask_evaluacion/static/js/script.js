// static/js/script.js
// Aquí puedes poner cualquier script general de tu sitio que no sea específico de una página.
// Por ejemplo, validaciones de formularios más complejas, animaciones, etc.

console.log("Script.js cargado.");

// Ejemplo: Si tuvieras un modal de confirmación general
// document.addEventListener('DOMContentLoaded', () => {
//     const confirmButtons = document.querySelectorAll('.confirm-action');
//     confirmButtons.forEach(button => {
//         button.addEventListener('click', (e) => {
//             if (!confirm('¿Estás seguro de que quieres realizar esta acción?')) {
//                 e.preventDefault();
//             }
//         });
//     });
// });