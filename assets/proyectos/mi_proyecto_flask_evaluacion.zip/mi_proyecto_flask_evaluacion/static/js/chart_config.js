// static/js/chart_config.js

document.addEventListener('DOMContentLoaded', function() {
    const ctx = document.getElementById('voteChart');
    const noDataMessage = document.getElementById('no-data-message');

    if (!ctx) {
        console.error("Canvas element 'voteChart' not found.");
        return;
    }

    fetch('/get_vote_data')
        .then(response => {
            if (!response.ok) {
                if (response.status === 401) {
                    // Si no autorizado, redirige al login
                    window.location.href = '/login';
                }
                throw new Error('Network response was not ok');
            }
            return response.json();
        })
        .then(data => {
            console.log("Datos de votación recibidos:", data);

            const labels = [];
            const voteCounts = [];
            const backgroundColors = [];
            const borderColors = [];
            let anyDataToShow = false;

            // Definir colores para cada barra
            const colors = {
                pagina1: { bg: 'rgba(255, 215, 0, 0.7)', border: 'rgba(255, 215, 0, 1)' }, // Amarillo
                pagina2: { bg: 'rgba(0, 123, 140, 0.7)', border: 'rgba(0, 123, 140, 1)' }, // Cian oscuro
                pagina3: { bg: 'rgba(108, 117, 125, 0.7)', border: 'rgba(108, 117, 125, 1)' }  // Gris azulado
            };

            for (const pageId in data) {
                if (data.hasOwnProperty(pageId)) {
                    // Solo añadir al gráfico si hay al menos 3 votos
                    if (data[pageId].total_votes >= 3) {
                        labels.push(pageId.charAt(0).toUpperCase() + pageId.slice(1).replace('pagina', 'Página ')); // Formato "Página 1", "Página 2", etc.
                        voteCounts.push(data[pageId].average_score); // O total_votes si prefieres mostrar la cantidad de votos
                        backgroundColors.push(colors[pageId].bg);
                        borderColors.push(colors[pageId].border);
                        anyDataToShow = true;
                    }
                }
            }

            if (anyDataToShow) {
                new Chart(ctx, {
                    type: 'bar', // Tipo de gráfico (bar, pie, line, etc.)
                    data: {
                        labels: labels,
                        datasets: [{
                            label: 'Puntuación Promedio', // O 'Cantidad de Votos'
                            data: voteCounts,
                            backgroundColor: backgroundColors,
                            borderColor: borderColors,
                            borderWidth: 1
                        }]
                    },
                    options: {
                        responsive: true,
                        scales: {
                            y: {
                                beginAtZero: true,
                                max: 5, // Escala de 1 a 5 para puntuación
                                title: {
                                    display: true,
                                    text: 'Puntuación Promedio'
                                }
                            },
                            x: {
                                title: {
                                    display: true,
                                    text: 'Página en Competencia'
                                }
                            }
                        },
                        plugins: {
                            legend: {
                                display: false // No mostrar leyenda si solo hay un dataset
                            },
                            tooltip: {
                                callbacks: {
                                    label: function(context) {
                                        return context.dataset.label + ': ' + context.raw;
                                    }
                                }
                            }
                        }
                    }
                });
                noDataMessage.style.display = 'none'; // Ocultar el mensaje si hay datos
            } else {
                ctx.style.display = 'none'; // Ocultar el canvas
                noDataMessage.style.display = 'block'; // Mostrar el mensaje
            }
        })
        .catch(error => console.error('Error al obtener datos de votación:', error));
});